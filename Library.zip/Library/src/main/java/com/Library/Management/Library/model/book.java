package com.Library.Management.Library.model;

import jakarta.persistence.*;


import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Entity
public class book {
    @Id
    private String bookId;
    private String bookName;
    private String bookAuthor;
    private String genre;
    private String bookStatus;
    private String comments;

    @OneToMany(mappedBy = "bookJoin")
    private List<bookRequest> bookRequests;
    @OneToMany(mappedBy = "books")
    private List<borrowing> borrowingListss;
    @OneToMany(mappedBy="books")
    private Set<notificationType> notificationType;
//
//    @OneToMany(mappedBy = "bookss")
//    private Set<dashboard> dashboardss;


    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getBookStatus() {
        return bookStatus;
    }

    public void setBookStatus(String bookStatus) {
        this.bookStatus = bookStatus;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<bookRequest> getBookRequests() {
        return bookRequests;
    }

    public void setBookRequests(List<bookRequest> bookRequests) {
        this.bookRequests = bookRequests;
    }
}
