package com.Library.Management.Library.controller;
import com.Library.Management.Library.model.dashboard;
import com.Library.Management.Library.service.dashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class dashboardController {

    @Autowired
    private dashboardService dashboardService;

    @GetMapping("/getdashboard")
    private List<dashboard> getdashboard(){
        return dashboardService.getdashboard();
    }

    @GetMapping("/getdashboard/{memberId}")
    private Optional<dashboard> getdashboardId(@PathVariable Integer memberId){
        return dashboardService.getdashboardId(memberId);
    }
}
