package com.Library.Management.Library.DTOs;

public class notificationDTO {
    private String NotificationId;
    private String BookName;
    private String BookStatus;
    private String BookAuthor;
    private String ApproveStatus;
    private String ReturnStatus;
    private String BookGenre;

    public String getBookGenre() {
        return BookGenre;
    }

    public void setBookGenre(String bookGenre) {
        BookGenre = bookGenre;
    }

    public String getNotificationId() {
        return NotificationId;
    }

    public void setNotificationId(String notificationId) {
        NotificationId = notificationId;
    }

    public String getBookName() {
        return BookName;
    }

    public void setBookName(String bookName) {
        BookName = bookName;
    }

    public String getBookStatus() {
        return BookStatus;
    }

    public void setBookStatus(String bookStatus) {
        BookStatus = bookStatus;
    }

    public String getBookAuthor() {
        return BookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        BookAuthor = bookAuthor;
    }

    public String getApproveStatus() {
        return ApproveStatus;
    }

    public void setApproveStatus(String approveStatus) {
        ApproveStatus = approveStatus;
    }

    public String getReturnStatus() {
        return ReturnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        ReturnStatus = returnStatus;
    }
}
