package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.bookDTO;
import com.Library.Management.Library.model.book;
import com.Library.Management.Library.repository.bookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class bookService {

    @Autowired
    private bookRepository bookRepository;

    public List<book> findAll(){
        return bookRepository.findAll();
    }

    public Optional<book> getBookId(String bookId) {
        return bookRepository.findById(bookId);
    }

    public void addBook(book book) {
        bookRepository.save(book);
    }

    public void updateBook(book book) {

        bookRepository.save(book);
    }

    public void deleteBook(String bookId) {
        bookRepository.deleteById(bookId);
    }

    public List<book> getBookrawQuery(String genre) {
        return bookRepository.findByrawQueryIn(genre);
    }

    public List<book> getBookauthor(String bookAuthor) {
        return bookRepository.findByauthor(bookAuthor);
    }

    public List<book> getBookComments(String comments) {
        return bookRepository.fingBycomments(comments);
    }

    public List<bookDTO> getdtoBook() {
        List<book>booklist=bookRepository.findAll();
        return booklist.stream().map(this::getdtobooks).toList();
    }

    private bookDTO getdtobooks(book book) {
        bookDTO b=new bookDTO();
        b.setName(book.getBookName());
        b.setAuthor(book.getBookAuthor());
        b.setGenre(book.getGenre());
        b.setStatus(book.getBookStatus());
        return b;
    }

    public bookDTO getdtoBookId(String bookId) {
        book book=bookRepository.findById(bookId).orElseThrow();
        return getdtobooks(book);
    }
}

