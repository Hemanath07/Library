package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.adminDTO;
import com.Library.Management.Library.model.admin;
import com.Library.Management.Library.repository.adminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class adminService {

    @Autowired
    private adminRepository adminRepository;


    public List<admin> findAll(){
        return adminRepository.findAll();
    }
    public Optional<admin> getadminByid(int adminId) {
        return adminRepository.findById(adminId);
    }

    public admin addAdmin(admin admin_detail) {
        System.out.println("Add member update...");
        return adminRepository.save(admin_detail);
    }


    public void updateAdmin(admin admin) {
         adminRepository.save(admin);
    }

    public void deleteAdmin(int adminId) {
        adminRepository.deleteById(adminId);
    }

    public List<adminDTO> getdtoadmin() {
        List<admin> adminList=adminRepository.findAll();
        return adminList.stream().map(this::getdtoadmins).toList();
    }

    private adminDTO getdtoadmins(admin admin) {
        adminDTO aa=new adminDTO();
        aa.setAdminId(admin.getAdmin_id());
        aa.setAdminName(admin.getAdminName());
        aa.setAdminAge(admin.getAge());
        aa.setCustomerId(admin.getCustomerId());
        aa.setLanguages(admin.getLanguages());
        return aa;
    }


}
