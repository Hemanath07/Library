package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.adminDTO;
import com.Library.Management.Library.model.admin;
import com.Library.Management.Library.service.adminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class adminController {

    @Autowired
    private adminService adminService;

    @GetMapping("/admin")
    public List<admin> getadmin(){
        return adminService.findAll();
    }

    @GetMapping("/admin/{adminId}")
    public Optional<admin> getadminByid(@PathVariable int adminId){
        return adminService.getadminByid(adminId);
    }

    @PostMapping("/dto/admin")
    public admin addAdmin(@RequestBody admin admin_detail) {
        return adminService.addAdmin(admin_detail);
    }

    @PutMapping("/dto/admin")
    public void updateAdmin(@RequestBody admin admin){
        adminService.updateAdmin(admin);
    }

    @DeleteMapping("/dto/admin/{adminId}")
    public void deleteAdmin(@PathVariable int adminId){
        adminService.deleteAdmin(adminId);
    }


    @GetMapping("/dto/admin")
    public List<adminDTO> getdtoadmin(){
        return adminService.getdtoadmin();
    }

}

