package com.Library.Management.Library.model;

import jakarta.persistence.*;


import java.util.List;


@Entity
public class member {

    @Id
    private Integer Member_Id;
    private String User_name;
    private String Password;
    private String customerId;
    private String Member_name;
    private Integer Age;
    private String Area_Of_Interest;
    private String Reading_Level;

    @OneToOne(mappedBy = "memberJoin")
    private bookRequest bookRequestList;

    @OneToMany(mappedBy = "memberJoins")
    private List<borrowing> borrowingList;

    @OneToOne(mappedBy = "memberIds")
    private dashboard dashboard;

//    @OneToMany(mappedBy = "members")
//    private Set<myHistory> myHistories;

    public member() {
    }

    public member(Integer member_Id, String user_name, String password, String member_name, Integer age, String area_Of_Interest, String reading_Level) {
        this.Member_Id = member_Id;
        this.User_name = user_name;
        this.Password = password;
        this.Member_name = member_name;
        this.Age = age;
        this.Area_Of_Interest = area_Of_Interest;
        this.Reading_Level = reading_Level;
    }

    public Integer getMember_Id() {
        return Member_Id;
    }

    public void setMember_Id(Integer member_Id) {
        Member_Id = member_Id;
    }

    public String getUser_name() {
        return User_name;
    }

    public void setUser_name(String user_name) {
        User_name = user_name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getMember_name() {
        return Member_name;
    }

    public void setMember_name(String member_name) {
        Member_name = member_name;
    }

    public Integer getAge() {
        return Age;
    }

    public void setAge(Integer age) {
        Age = age;
    }

    public String getArea_Of_Interest() {
        return Area_Of_Interest;
    }

    public void setArea_Of_Interest(String area_Of_Interest) {
        Area_Of_Interest = area_Of_Interest;
    }

    public String getReading_Level() {
        return Reading_Level;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public void setReading_Level(String reading_Level) {
        Reading_Level = reading_Level;
    }

}