package com.Library.Management.Library.repository;

import com.Library.Management.Library.model.dashboard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public interface dashboardRepository extends JpaRepository<dashboard,Integer> {
}
