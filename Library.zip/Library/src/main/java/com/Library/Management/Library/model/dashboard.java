package com.Library.Management.Library.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class dashboard {

    @Id
    private String customerId;
    @OneToOne
    @JoinColumn(name = "memberId")
    private member memberIds;
    @OneToOne
    @JoinColumn(name = "adminId")
    private admin admins;
    @ManyToOne
    @JoinColumn(name = "notificationId")
    private notificationType notificationTypes;
    @ManyToOne
    @JoinColumn(name = "bookId")
    private book bookss;

}
