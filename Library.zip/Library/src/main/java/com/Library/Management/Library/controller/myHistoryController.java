package com.Library.Management.Library.controller;

import com.Library.Management.Library.model.myHistory;
import com.Library.Management.Library.service.myHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class myHistoryController {

    @Autowired
    private myHistoryService myHistoryService;

    @GetMapping("/myhistory")
    private List<myHistory> getmyHistory(){
        return myHistoryService.getmyHistory();
    }

    @GetMapping("/myhistory/{memberId}")
    private Optional<myHistory> getmyHistortyId(@PathVariable Integer memberId){
        return myHistoryService.getmyHistoryId(memberId);
    }
}
