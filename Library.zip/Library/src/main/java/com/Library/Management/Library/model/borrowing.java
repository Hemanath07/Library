package com.Library.Management.Library.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.sql.Date;

@Entity
public class borrowing {

    @Id
    private String OrderId;
    @ManyToOne
    @JoinColumn(name="memberId")
    private member memberJoins;
    @ManyToOne
    @JoinColumn(name = "requestId")
    private bookRequest bookRequestsss;
    @ManyToOne
    @JoinColumn(name = "bookId")
    private book books;
    private String approveStatus;
    private Date borrowDate;
    private Date returnDate;
    private Integer fineAmount;

    public String getOrderId() {
        return OrderId;
    }

    public void setOrderId(String orderId) {
        OrderId = orderId;
    }

    public member getMemberJoins() {
        return memberJoins;
    }

    public void setMemberJoins(member memberJoins) {
        this.memberJoins = memberJoins;
    }

    public bookRequest getBookRequests() {
        return bookRequestsss;
    }

    public void setBookRequests(bookRequest bookRequests) {
        this.bookRequestsss = bookRequests;
    }

    public book getBooks() {
        return books;
    }

    public void setBooks(book books) {
        this.books = books;
    }

    public String getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(String approveStatus) {
        this.approveStatus = approveStatus;
    }

    public Date getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        this.borrowDate = borrowDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public Integer getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(Integer fineAmount) {
        this.fineAmount = fineAmount;
    }
}
