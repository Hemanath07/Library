package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.borrowDTO;
import com.Library.Management.Library.model.borrowing;
import com.Library.Management.Library.service.borrowingService;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class borrowingController {

    @Autowired
    private borrowingService borrowingService;

    @RequestMapping("/getborrow")
    private List<borrowing> getBorrow(){
        return borrowingService.getBorrow();
    }

    @GetMapping("/dto/borrow")
    private List<borrowDTO> getdtoborrow(){
        return borrowingService.getdtoborrow();
    }

}
