package com.Library.Management.Library.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Date;
import java.util.Set;


@Entity
public class notificationType {
    @Id
    private String notificationId;
    @ManyToOne
    @JoinColumn(name = "bookId")
    private book books;
    private String approveStatus;
    private String returnStatus;
    private Date returnDate;

    @OneToMany(mappedBy = "notificationTypes")
    private Set<dashboard> dashboardSet;

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public book getBooks() {
        return books;
    }

    public void setBooks(book books) {
        this.books = books;
    }

    public String getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(String approveStatus) {
        this.approveStatus = approveStatus;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public Set<dashboard> getDashboardSet() {
        return dashboardSet;
    }

    public void setDashboardSet(Set<dashboard> dashboardSet) {
        this.dashboardSet = dashboardSet;
    }
}
