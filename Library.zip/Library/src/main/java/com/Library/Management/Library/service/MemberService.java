package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.memberDTO;
import com.Library.Management.Library.model.member;
import com.Library.Management.Library.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    public List<member> findAll() {
        return memberRepository.findAll();
    }
    public Optional<member> getuser(Integer id){
        return memberRepository.findById(id);
    }

    public List<memberDTO> getdtomember() {
        List<member>memberList=memberRepository.findAll();
        return memberList.stream().map(this::getdtomembers).toList();
    }

    private memberDTO getdtomembers(member member) {
        memberDTO a=new memberDTO();
        a.setName(member.getMember_name());
        a.setAge(member.getAge());
        a.setInterest(member.getArea_Of_Interest());
        a.setReadLevel(member.getReading_Level());
        a.setId(member.getMember_Id());
        a.setCustomerId(member.getCustomerId());
        return  a;
    }

    public memberDTO getdtomemberId(Integer memberId){
        member member=memberRepository.findById(memberId).orElseThrow();
        return getdtomembers(member);
    }

    public void updateMember(member member) {
        memberRepository.save(member);
    }

    public void addMember(member member) {
        memberRepository.save(member);
    }

    public void deleteMember(Integer memberId) {
        memberRepository.deleteById(memberId);
    }

}
