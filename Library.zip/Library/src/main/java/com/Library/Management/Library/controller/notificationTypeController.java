package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.notificationDTO;
import com.Library.Management.Library.model.notificationType;
import com.Library.Management.Library.service.notificationTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class notificationTypeController {

    @Autowired
    private notificationTypeService notificationTypeService;

    @GetMapping("/getnotification")
    private List<notificationType> getnotification(){
        return notificationTypeService.getnotification();
    }

    @GetMapping("/getnotification/{notificationId}")
    private Optional<notificationType> getnotificationId(@PathVariable String notificationId){
        return notificationTypeService.getnotificationId(notificationId);
    }

    @GetMapping("/dto/notificationmem")
    private List<notificationDTO> getdtonotification(){
        return notificationTypeService.getdtonotification();
    }
}
