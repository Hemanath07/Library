package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.memberDTO;
import com.Library.Management.Library.model.member;
import com.Library.Management.Library.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class MemberController {
   @Autowired
   private MemberService memberService;
    @RequestMapping("/members")
    public List<member> getMember(){
        return memberService.findAll();
    }
    @RequestMapping("/members/{id}")
    public Optional<member> getuser(@PathVariable("id") Integer id){
        return memberService.getuser(id);
    }

    @RequestMapping("/dto/member")
    public List<memberDTO> getdtomember(){
        return memberService.getdtomember();
    }

    @RequestMapping("/dto/member/{memberId}")
    public memberDTO getdtomemberId(@PathVariable Integer memberId){
        return memberService.getdtomemberId(memberId);
    }

    @PutMapping("/dto/member")
    public void updateMember(@RequestBody member member){
        memberService.updateMember(member);
    }

    @PostMapping("/dto/member")
    public void addMember(@RequestBody member member){
        memberService.addMember(member);
    }

    @DeleteMapping("/dto/member/{memberId}")
    public void deleteMember(@PathVariable Integer memberId){
        memberService.deleteMember(memberId);
    }
}
