package com.Library.Management.Library.service;

import com.Library.Management.Library.model.myHistory;
import com.Library.Management.Library.repository.myHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class myHistoryService {

    @Autowired
    private myHistoryRepository myHistoryRepository;

    public List<myHistory> getmyHistory() {
        return myHistoryRepository.findAll();
    }

    public Optional<myHistory> getmyHistoryId(Integer memberId) {
        return myHistoryRepository.findById(memberId);
    }
}
