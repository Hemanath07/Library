package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.bookDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.Library.Management.Library.service.bookService;
import com.Library.Management.Library.model.book;

import java.util.List;
import java.util.Optional;

@RestController
public class bookController {
    @Autowired
    private bookService bookService;

    @GetMapping("/book")
    public List<book> getBook(){
        return bookService.findAll();
    }

    @GetMapping("/book/{bookId}")
    public Optional<book> getBookId(@PathVariable String bookId){
        return bookService.getBookId(bookId);
    }

    @GetMapping("/book/genre")
    public List<book> getBookrawQuery(@RequestParam String genre){
        return bookService.getBookrawQuery(genre);
    }

    @GetMapping("/book/comments")
    public List<book> getBookComments(@RequestParam String comments){
        return bookService.getBookComments(comments);
    }
    @GetMapping("/book/author")
    public List<book> getBookauthor(@RequestParam String bookAuthor){
        return bookService.getBookauthor(bookAuthor);
    }

    @PostMapping("/dto/book")
    public void addBook(@RequestBody book book){
        bookService.addBook(book);
    }

    @PutMapping("/dto/book")
    public void updateBook(@RequestBody book book){
        bookService.updateBook(book);
    }

    @DeleteMapping("/dto/book/{bookId}")
    public void deleteBook(@PathVariable String bookId){
        bookService.deleteBook(bookId);
    }
    @GetMapping("/dto/book")
    public List<bookDTO> getdtoBook(){
        return bookService.getdtoBook();
    }

    @GetMapping("/dto/book/{bookId}")
    public bookDTO getdtoBookId(@PathVariable String bookId) {
        return bookService.getdtoBookId(bookId);
    }

}

