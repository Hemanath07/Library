package com.Library.Management.Library.repository;

import com.Library.Management.Library.model.myHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface myHistoryRepository extends JpaRepository<myHistory,Integer> {
}
