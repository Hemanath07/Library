package com.Library.Management.Library.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Date;
import java.util.List;

@Entity
public class bookRequest {

    @Id
    private Integer requestId;
    @ManyToOne
    @JoinColumn(name = "bookId")
    private book bookJoin;
    @OneToOne
    @JoinColumn(name = "memberId")
    private member memberJoin;
    private Date requestDate;

    @OneToMany(mappedBy = "bookRequestsss")
    private List<borrowing> borrowingLists;

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public book getBookJoin() {
        return bookJoin;
    }

    public void setBookJoin(book bookJoin) {
        this.bookJoin = bookJoin;
    }

    public member getMemberJoin() {
        return memberJoin;
    }

    public void setMemberJoin(member memberJoin) {
        this.memberJoin = memberJoin;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public List<borrowing> getBorrowingLists() {
        return borrowingLists;
    }

    public void setBorrowingLists(List<borrowing> borrowingLists) {
        this.borrowingLists = borrowingLists;
    }
}
