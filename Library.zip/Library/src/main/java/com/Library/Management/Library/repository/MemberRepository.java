package com.Library.Management.Library.repository;

import com.Library.Management.Library.DTOs.memberDTO;
import com.Library.Management.Library.model.member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface MemberRepository extends JpaRepository<member,Integer> {
}
