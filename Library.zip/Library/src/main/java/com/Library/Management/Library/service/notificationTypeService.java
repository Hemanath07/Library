package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.bookDTO;
import com.Library.Management.Library.DTOs.notificationDTO;
import com.Library.Management.Library.model.notificationType;
import com.Library.Management.Library.repository.notificationTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class notificationTypeService {

    @Autowired
    private notificationTypeRepository notificationTypeRepository;

    public List<notificationType> getnotification() {
        return notificationTypeRepository.findAll();
    }


    public Optional<notificationType> getnotificationId(String notificationId) {
        return notificationTypeRepository.findById(notificationId);
    }

    public List<notificationDTO> getdtonotification() {
        List<notificationType> notificationTypes = notificationTypeRepository.findAll();
        return notificationTypes.stream().map(this::getdtonotifications).toList();
    }

    private notificationDTO getdtonotifications(notificationType notificationType) {
        bookDTO book=new bookDTO();
        if(notificationType.getBooks()!=null){
            book.setName(notificationType.getBooks().getBookName());
            book.setStatus(notificationType.getBooks().getBookStatus());
            book.setAuthor(notificationType.getBooks().getBookAuthor());
            book.setGenre(notificationType.getBooks().getGenre());
        }
        notificationDTO abc= new notificationDTO();
        abc.setNotificationId(notificationType.getNotificationId());
        abc.setBookName(book.getName());
        abc.setBookAuthor(book.getAuthor());
        abc.setBookGenre(book.getGenre());
        abc.setReturnStatus(notificationType.getReturnStatus());
        abc.setBookStatus(book.getStatus());
        abc.setApproveStatus(notificationType.getApproveStatus());
        return abc;
    }
}
