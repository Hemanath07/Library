package com.Library.Management.Library.controller;

import com.Library.Management.Library.DTOs.bookRequestDTO;
import com.Library.Management.Library.model.bookRequest;
import com.Library.Management.Library.service.bookRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class bookRequestController {

    @Autowired
    private bookRequestService bookRequestService;

    @GetMapping("/bookrequest")
    private List<bookRequest> getbookrequest(){
        return bookRequestService.getbookrequest();
    }
    @GetMapping("/bookrequest/{requestId}")
    private Optional<bookRequest> getbookrequestId(@PathVariable Integer requestId){
        return bookRequestService.getbookrequestId(requestId);
    }

    @PutMapping("/bookrequest")
    private void updaterequest(@RequestBody bookRequest bookRequest){
        bookRequestService.updaterequest(bookRequest);
    }

    @GetMapping("/dto/bookrequest")
    private List<bookRequestDTO> getdtobookrequest(){
        return bookRequestService.getdtobookrequest();
    }
}
