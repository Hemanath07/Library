package com.Library.Management.Library.DTOs;

public class dog extends Animal{
    
}
