package com.Library.Management.Library.repository;

import com.Library.Management.Library.model.book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface bookRepository extends JpaRepository<book, String> {
    @Query(nativeQuery = true,value = "select * from book where genre =?1")
    List<book> findByrawQueryIn(String genre);

    @Query(nativeQuery = true,value = "select * from book where book_Author =?1")
    List<book> findByauthor(String bookAuthor);

    @Query(nativeQuery = true,value = "select bookId from book where comments=?1")
    List<book> fingBycomments(String comments);
}
