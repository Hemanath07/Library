package com.Library.Management.Library.DTOs;

public class memberDTO {
    private Integer Id;
    private String Name;
    private Integer Age;
    private String Interest;
    private String ReadLevel;
    private String CustomerId;

    public String getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(String customerId) {
        CustomerId = customerId;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Integer getAge() {
        return Age;
    }

    public void setAge(Integer age) {
        Age = age;
    }

    public String getInterest() {
        return Interest;
    }

    public void setInterest(String interest) {
        Interest = interest;
    }

    public String getReadLevel() {
        return ReadLevel;
    }

    public void setReadLevel(String readLevel) {
        ReadLevel = readLevel;
    }

}
