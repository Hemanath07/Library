package com.Library.Management.Library.service;


import com.Library.Management.Library.model.dashboard;
import com.Library.Management.Library.repository.dashboardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class dashboardService {

    @Autowired
    private dashboardRepository dashboardRepository;

    public List<dashboard> getdashboard() {
        return dashboardRepository.findAll();
    }

    public Optional<dashboard> getdashboardId(Integer memberId) {
        return dashboardRepository.findById(memberId);
    }
}
