package com.Library.Management.Library.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;

@Data
@Entity
public class myHistory {
//    @Id
//    @ManyToOne
//    @JoinColumn(name = "Member_Id")
//    private member members;

//
//    @ManyToOne
//    @JoinColumn(name = "bookId")
//    private book books;
    @Id
    private Integer memberId;
    private String myBooks;
    private String returnStatus;
    private Integer fineAmount;
    private Integer myStreaks;
}
