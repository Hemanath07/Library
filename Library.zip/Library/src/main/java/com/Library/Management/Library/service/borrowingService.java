package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.borrowDTO;
import com.Library.Management.Library.model.borrowing;
import com.Library.Management.Library.repository.borrowingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class borrowingService {

    @Autowired
    private borrowingRepository borrowingRepository;

    public List<borrowing> getBorrow() {
        return borrowingRepository.findAll();
    }

    public List<borrowDTO> getdtoborrow() {
        List<borrowing>borrowings=borrowingRepository.findAll();
        return borrowings.stream().map(this::getdtoborrows).toList();
    }

    private borrowDTO getdtoborrows(borrowing borrowing) {
        borrowDTO obj=new borrowDTO();
        obj.setOrderId(borrowing.getOrderId());
        obj.setMemberId(borrowing.getMemberJoins().getMember_Id());
        obj.setBookId(borrowing.getBooks().getBookId());
        obj.setBookStatus(borrowing.getApproveStatus());
        return obj;
    }

}
