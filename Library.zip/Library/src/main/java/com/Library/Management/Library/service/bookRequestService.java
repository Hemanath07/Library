package com.Library.Management.Library.service;

import com.Library.Management.Library.DTOs.bookRequestDTO;
import com.Library.Management.Library.model.bookRequest;
import com.Library.Management.Library.repository.bookRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class bookRequestService {

    @Autowired
    private bookRequestRepository bookRequestRepository;

    public List<bookRequest> getbookrequest() {
        return bookRequestRepository.findAll();
    }

    public Optional<bookRequest> getbookrequestId(Integer requestId) {
        return bookRequestRepository.findById(requestId);
    }

    public void updaterequest(bookRequest bookRequest) {
        bookRequestRepository.save(bookRequest);
    }

    public List<bookRequestDTO> getdtobookrequest() {
        List<bookRequest> bookRequestList = bookRequestRepository.findAll();
        return bookRequestList.stream().map(this::getdtobookrequests).toList();
    }

    private bookRequestDTO getdtobookrequests(bookRequest bookRequest) {
        bookRequestDTO aaa=new bookRequestDTO();
        aaa.setRequestId(bookRequest.getRequestId());
        aaa.setMemberId(bookRequest.getMemberJoin().getMember_Id());
        aaa.setBookId(bookRequest.getBookJoin().getBookId());
        aaa.setRequestDate(bookRequest.getRequestDate());
        return aaa;
    }
}
